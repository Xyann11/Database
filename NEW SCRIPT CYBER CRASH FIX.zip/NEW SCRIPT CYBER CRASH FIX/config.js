module.exports = {
  BOT_TOKEN:
 "7541971446:AAEdkOH8QNpzqrSE-YGLJLydoDbHKgcbw2I",
};